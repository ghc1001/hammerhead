Testplan
========

Copyright 2018 Morgan Stanley.

This project includes software developed at Morgan Stanley
(http://www.morganstanley.com).

Tempita
=======

https://github.com/gjhiggins/tempita/blob/master/docs/license.txt

Copyright (c) 2008 Ian Bicking and Contributors



