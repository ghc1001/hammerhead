"""
  Entry point for schema serialization bindings.
"""

from .. import assertions as asr
from . import assertions as asr_schemas
from . import base

registry = base.registry
