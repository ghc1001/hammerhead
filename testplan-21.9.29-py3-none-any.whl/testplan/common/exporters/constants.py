# PDF displayed tables constants, used for table.log, table.match etc.
PAGE_WIDTH = 540

NUM_DISPLAYED_ROWS = 10

CELL_STRING_LENGTH = 60

INNER_BORDER = 0.25

OUTER_BORDER = 0.75
