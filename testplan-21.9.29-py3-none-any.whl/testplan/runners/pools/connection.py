"""Connections module."""

import pickle
import warnings
import time
import queue
import abc

import zmq

from testplan.common import entity
from testplan.common.utils import logger


class Client(logger.Loggable, metaclass=abc.ABCMeta):
    """
    Workers are Client in Pool/Worker communication.
    Abstract base class for workers to communicate with its pool."""

    def __init__(self):
        super(Client, self).__init__()
        self.active = False

    @abc.abstractmethod
    def connect(self, server):
        """Connect client to server"""
        self.active = True

    @abc.abstractmethod
    def disconnect(self):
        """Disconnect client from server"""
        self.active = False

    @abc.abstractmethod
    def send(self, message):
        """
        Sends a message to server
        :param message: Message to be sent.
        :type message:
            :py:class:`~testplan.runners.pools.communication.Message`
        """
        pass

    @abc.abstractmethod
    def receive(self):
        """Receives response to the message sent"""
        pass

    def send_and_receive(self, message, expect=None):
        """
        Send and receive shortcut. Optionally assert that the response is
        of the type expected. I.e For a TaskSending message, an Ack is
        expected.

        :param message: Message sent.
        :type message:
            :py:class:`~testplan.runners.pools.communication.Message`
        :param expect: Expected command of message received.
        :type expect: ``NoneType`` or ``tuple`` or ``list`` or
            :py:class:`~testplan.runners.pools.communication.Message`
        :return: Message received.
        :rtype: ``object``
        """
        if not self.active:
            return None

        try:
            self.send(message)
        except Exception as exc:
            self.logger.exception("Exception on transport send: %s.", exc)
            raise RuntimeError("On transport send - {}.".format(exc))

        try:
            received = self.receive()
        except Exception as exc:
            self.logger.exception("Exception on transport receive: %s.", exc)
            raise RuntimeError("On transport receive - {}.".format(exc))

        if expect is not None:
            if received is None:
                raise RuntimeError(
                    "Received None when {} was expected.".format(expect)
                )
            if isinstance(expect, (tuple, list)):
                assert received.cmd in expect
            else:
                assert received.cmd == expect
        return received


class QueueClient(Client):
    """
    Queue based client implementation, for thread pool workers to
    communicate with its pool.
    """

    def __init__(self, recv_sleep=0.05):
        super(QueueClient, self).__init__()
        self._recv_sleep = recv_sleep
        self.requests = None

        # single-producer(pool) single-consumer(worker) FIFO queue
        self.responses = []

    def connect(self, requests):
        """
        Connect to the request queue of Pool
        :param requests: request queue of pool that worker should write to.
        :type requests: Queue
        """
        self.requests = requests
        self.active = True

    def disconnect(self):
        """Disconnect worker from pool"""
        self.active = False
        self.requests = None

    def send(self, message):
        """
        Worker sends a message
        :param message: Message to be sent.
        :type message:
            :py:class:`~testplan.runners.pools.communication.Message`
        """
        if self.active:
            self.requests.put(message)

    def receive(self):
        """
        Worker receives response to the message sent, this method blocks.
        :return: Response to the message sent.
        :type: :py:class:`~testplan.runners.pools.communication.Message`
        """
        while self.active:
            try:
                return self.responses.pop()
            except IndexError:
                time.sleep(self._recv_sleep)

    def respond(self, message):
        """
        Used by :py:class:`~testplan.runners.pools.base.Pool` to respond to
        worker request.

        :param message: Respond message.
        :type message:
            :py:class:`~testplan.runners.pools.communication.Message`
        """
        if self.active:
            self.responses.append(message)
        else:
            raise RuntimeError("Responding to inactive worker")


class ZMQClient(Client):
    """
    ZMQ based client implementation for process worker to communicate
    with its pool.

    :param address: Pool server address to connect to.
    :type address: ``float``
    :param recv_sleep: Sleep duration in msg receive loop.
    :type recv_sleep: ``float``
    """

    def __init__(self, address, recv_sleep=0.05, recv_timeout=5):
        super(ZMQClient, self).__init__()
        self._address = address
        self._recv_sleep = recv_sleep
        self._recv_timeout = recv_timeout
        self._context = None
        self._sock = None

        self.connect()  # auto connect

    def connect(self):
        """Connect to a ZMQ Server"""
        self._context = zmq.Context()
        self._sock = self._context.socket(zmq.REQ)
        self._sock.connect("tcp://{}".format(self._address))
        self.active = True

    def disconnect(self):
        """Disconnect from Server"""
        self.active = False
        self._sock.close()
        self._sock = None
        self._context.destroy()
        self._context = None
        self._address = None

    def send(self, message):
        """
        Worker sends a message.

        :param message: Message to be sent.
        :type message:
            :py:class:`~testplan.runners.pools.communication.Message`
        """
        if self.active:
            self._sock.send(pickle.dumps(message))

    def receive(self):
        """
        Worker tries to receive the response to the message sent until timeout.

        :return: Response to the message sent.
        :type: :py:class:`~testplan.runners.pools.communication.Message`
        """
        start_time = time.time()

        while self.active:
            try:
                received = self._sock.recv(flags=zmq.NOBLOCK)
                try:
                    loaded = pickle.loads(received)
                except Exception as exc:
                    print("Deserialization error. - {}".format(exc))
                    raise
                else:
                    return loaded
            except zmq.Again:
                if time.time() - start_time > self._recv_timeout:
                    print(
                        "Transport receive timeout {}s reached!".format(
                            self._recv_timeout
                        )
                    )
                    return None
                time.sleep(self._recv_sleep)
        return None


class ZMQClientProxy:
    """
    Representative of a process worker's transport in local worker object.
    """

    def __init__(self):
        self.active = False
        self.connection = None
        self.address = None

    def connect(self, server):
        self.connection = server.sock
        self.address = server.address
        self.active = True

    def disconnect(self):
        self.active = False
        self.connection = None
        self.address = None

    def respond(self, message):
        """
        Used by :py:class:`~testplan.runners.pools.base.Pool` to respond to
        worker request.

        :param message: Respond message.
        :type message:
            :py:class:`~testplan.runners.pools.communication.Message`
        """
        if self.active:
            self.connection.send(pickle.dumps(message))
        else:
            raise RuntimeError("Responding to inactive worker")


class Server(entity.Resource, metaclass=abc.ABCMeta):
    """
    Abstract base class for pools to communicate to its workers.
    """

    def __init__(self):
        super(Server, self).__init__()

    def starting(self):
        """Server starting logic."""
        self.status.change(self.status.STARTED)  # Start is async

    def stopping(self):
        """Server stopping logic."""
        self.status.change(self.status.STOPPED)  # Stop is async

    def aborting(self):
        """Abort policy - no abort actions are required in the base class."""
        pass

    @abc.abstractmethod
    def register(self, worker):
        """
        Register a new worker. Workers should be registered after the
        connection manager is started and will be automatically unregistered
        when it is stopped.
        """
        if self.status != self.status.STARTED:
            raise RuntimeError(
                "Can only register workers when started."
                f" Current state is {self.status.tag}."
            )

    @abc.abstractmethod
    def accept(self):
        """
        Accepts a new message from worker. This method should not block - if
        no message is queued for receiving it should return None.

        :return: Message received from worker transport, or None.
        :rtype: ``NoneType`` or
            :py:class:`~testplan.runners.pools.communication.Message`
        """
        pass


class QueueServer(Server):
    """
    Queue based server implementation, for thread pool to get requests
    from workers.
    """

    def __init__(self):
        super(QueueServer, self).__init__()

        # multi-producer(workers) single-consumer(pool) FIFO queue
        self.requests = None

    def starting(self):
        self.requests = queue.Queue()
        super(QueueServer, self).starting()

    def register(self, worker):
        super(QueueServer, self).register(worker)
        worker.transport.connect(self.requests)

    def accept(self):
        """
        Accepts the next request in the request queue.

        :return: Message received from worker transport, or None.
        :rtype: ``NoneType`` or
            :py:class:`~testplan.runners.pools.communication.Message`
        """
        try:
            return self.requests.get_nowait()
        except queue.Empty:
            return None


class ZMQServer(Server):
    """
    ZMQ based server implementation, for process/remote/treadmill pool
    to get request from workers.
    """

    def __init__(self):
        super(ZMQServer, self).__init__()

        # Here, context is a factory class provided by ZMQ that creates
        # sockets. Context and other attributes below are set when starting
        # and cleaned up when stopping.
        self._zmq_context = None
        self._sock = None
        self._address = None

    @property
    def sock(self):
        return self._sock

    @property
    def address(self):
        return self._address

    def starting(self):
        """Create a ZMQ context and socket to handle TCP communication."""
        if self.parent is None:
            raise RuntimeError("Parent pool was not set - cannot start.")

        self._zmq_context = zmq.Context()
        self._sock = self._zmq_context.socket(zmq.REP)
        if self.parent.cfg.port == 0:
            port_selected = self._sock.bind_to_random_port(
                "tcp://{}".format(self.parent.cfg.host)
            )
        else:
            self._sock.bind(
                "tcp://{}:{}".format(
                    self.parent.cfg.host, self.parent.cfg.port
                )
            )
            port_selected = self.parent.cfg.port
        self._address = "{}:{}".format(self.parent.cfg.host, port_selected)
        super(ZMQServer, self).starting()

    def _close(self):
        """Closes TCP connections managed by this object.."""
        self.logger.debug("Closing TCP connections for %s", self.parent)
        if self._sock is not None:
            self._sock.close()
            self._sock = None
        if self._zmq_context is not None:
            self._zmq_context.destroy()
            self._zmq_context = None
        self._address = None

    def stopping(self):
        """
        Terminate the ZMQ context and socket when stopping. We require that
        all workers are stopped before stopping the connection manager, so
        that we can safely remove references to connection sockets from the
        worker.
        """
        self._close()
        super(ZMQServer, self).stopping()

    def aborting(self):
        """Terminate the ZMQ context and socket when aborting."""
        if self._sock is not None:
            self._close()
        super(ZMQServer, self).aborting()

    def register(self, worker):
        """Register a new worker."""
        super(ZMQServer, self).register(worker)
        worker.transport.connect(self)

    def accept(self):
        """
        Accepts a new message from worker. Doesn't block if no message is
        queued for receiving.

        :return: Message received from worker transport, or None.
        :rtype: ``NoneType`` or
            :py:class:`~testplan.runners.pools.communication.Message`
        """
        try:
            return pickle.loads(self._sock.recv(flags=zmq.NOBLOCK))
        except zmq.Again:
            return None

    def __del__(self):
        """
        Check that ZMQ sockets are properly closed when this manager is
        garbage-collected. If not we close them now as a fallback.
        """
        # Use getattr() with a default here - there is no guarantee that
        # __init__() has completed successfully when __del__() is called.
        if (getattr(self, "_sock", None) is not None) or (
            getattr(self, "_zmq_context", None) is not None
        ):
            warnings.warn("Pool TCP connections were not closed.")
            self._close()
