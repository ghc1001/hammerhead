export const ALL = 'all';
export const FAILED = 'fail';
export const PASSED = 'pass';
